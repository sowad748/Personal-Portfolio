    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 p-3 mx-auto">
                    <h4>Information</h4>
                    <p>Shooping & Delivery</p>
                    <p>Warranty & Repairs</p>
                    <p>Return & Refund</p>
                    <p>Terms & Condition</p>
                    <p>Privacy & Policy</p>
                    <p>About Us</p>
                </div>
                <div class="col-md-4 p-3 mx-auto">
                    <h4>More</h4>
                    <p>Find a GYM</p>
                    <p>About Us</p>
                    <p>News</p>
                    <p>Payment Method</p>

                </div>
                <div class="col-md-4 p-3 mx-auto">
                    <h4>Contact US</h4>
                    <p>Bashundhara,Dhaka,Bangldesh</p>
                    <p>+87000000000000</p>
                    <p>+87000000000000</p>
                    <p>Sat-Fri 7.30pm</p>

                </div>
            </div>
            <p class="text-center py-3"><i class="fa fa-copyright" aria-hidden="true"></i> Gym Management All Rights
                Reserved</p>
        </div>
    </div>
